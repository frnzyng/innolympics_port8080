import '/flutter_flow/flutter_flow_util.dart';
import 'sample_bill_widget.dart' show SampleBillWidget;
import 'package:flutter/material.dart';

class SampleBillModel extends FlutterFlowModel<SampleBillWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
