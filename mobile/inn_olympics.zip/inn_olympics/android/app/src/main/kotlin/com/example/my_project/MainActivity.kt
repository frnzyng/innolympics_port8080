package com.mycompany.innolympics

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
